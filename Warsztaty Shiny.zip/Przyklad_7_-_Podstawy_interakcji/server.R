shinyServer(function(input,output){
  #renderImage - zdjecie
  #renderPlot - wykres
  #renderPrint - cokolwiek drukowanego
  #renderTable - ramki danych, macierz, data table
  #renderText - character
  #renderUI - Shiny tag albo HTML
})
