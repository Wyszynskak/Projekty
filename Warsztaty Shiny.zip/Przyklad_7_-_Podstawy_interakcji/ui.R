#W tym przykładzie wypisałam podstawowe funkcje, które są odpowiedzialne za 
#output i render(w pliku server.R) np. jeśli chcemy w naszej aplikacji wyświetlić
#wykres używamy plotOutput, a w server.R renderPlot(). 

shinyUI(fluidPage(
  #htmlOutput - czysty HTML
  #imageOutput - obrazki
  #plotOutput - wykresy
  #tableOutput - tabele/ramki danych
  #textOutput - tekst
  #uiOutput - czysty HTML (używane np. w interaktywnym menu)
  #verbatimTextOutput - tekst 
))
