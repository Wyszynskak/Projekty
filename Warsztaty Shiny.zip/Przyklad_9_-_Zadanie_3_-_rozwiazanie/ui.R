
shinyUI(fluidPage(
  titlePanel("Sześcienna kostka"),
 sidebarLayout(
   sidebarPanel(
     actionButton("przycisk", label=h3("Rzuć kostką"))
   ),
   
   mainPanel(
     textOutput("liczba")
   )
 )
))
