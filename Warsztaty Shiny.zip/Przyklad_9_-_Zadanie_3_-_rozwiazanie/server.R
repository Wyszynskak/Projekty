


shinyServer(function(input,output){
  
  output$liczba <- renderText({  
      input$przycisk #Po to ,żeby funkcja zareagowała na naciśnięcie przycisku
      
      as.character(sample(1:6,1))
    })

})

