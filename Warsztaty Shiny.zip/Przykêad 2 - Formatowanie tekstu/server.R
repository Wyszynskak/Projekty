shinyServer(function(input,output){

})
