shinyUI(fluidPage(
  titlePanel("Jak zapanować nad tekstem?"),
  sidebarLayout(
    sidebarPanel(),
    mainPanel(
      
      #Tytuły - różne rozmiary
      h1("TYTUŁY"),
      h1("h1() Pierwszy poziom tytułu"),
      h2("h2() Drugi poziom tytułu"),
      h3("h3() Trzeci poziom tytułu"),
      h4("h4() Czwarty poziom tytułu"),
      h5("h5() Piąty poziom tytułu"),
      h6("h6() Szósty poziom tytułu"),
      
      #Wyśrodkowanie tekstu
      h6("Tytuł na środku", align="center"),
      
      #Paragraf tekstu
      p("p() To będzie bardzo imponujaco długi paragraf tekstu, który ma
         pokazać jak długa może być pojedyncza linijka tekstu. Zauważcie,
         że poprzednie funkcje same zapewniały nam znaki nowej linii..."),
      
      #Nowe, puste linijki
      br(),
      br(),
      
      #Inne funkcje (bez automatycznej nowej linii)
      p("Są jeszcze inne funkcje, które nie stosują nowej linii:"),
      strong("strong() daje pogrubienie tekstu"),
       br(),
      em("em() zwraca pochyły tekst"),
       br(),
      a("a(\" \",href=\"link\") Dodajmy jeszcze link: http://www.google.pl"),
       br(),
      code("code() Albo trochę kodu z R:
         x<-1:10;
         mean(x)"),
      
      p("Tekst możemy także kolorować argumentem style='color:green'", 
        style="color:green"),
      
      #Łączenie możliwości w jednym tekście
      p("Zagnieżdżając funkcję możemy", strong(" pogrubić tekst, "), 
        em("pochylić go,"), strong("czy pokolorować tylko jego część", 
                              style="color:purple"))
    )
  )
))
