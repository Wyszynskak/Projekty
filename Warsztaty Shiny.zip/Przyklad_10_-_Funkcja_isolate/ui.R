#Tutaj wykorzystałam ponownie przykład z funkcją sinus i cosinus. Urozmaiciłam ją trochę
#by pokazać działanie textInput. Zanim dokomentujesz linijkę w kodzie przeczytaj
#plik server.R


  shinyUI(fluidPage(
    titlePanel("Trygonometria"),
    sidebarLayout(
      sidebarPanel(
        radioButtons("wybor", label=h3("Funkcja"), choices=list("Sinus"=1,
                                                                "Cosinus"=2),
                     selected=1),
        
        sliderInput("dziedzina", label=h3("Dziedzina funkcji"), min=-2*pi, max=2*pi, 
                    round=1, value=c(-pi, pi)),
        textInput("tytul", label="Podaj tytuł wykresu:", value="")
        #,actionButton("przycisk", label="Zatwierdź")
      ),
      
      mainPanel(
        plotOutput("wykres")
      )
    )
  ))

