#Przeczytaj najpierw plik ui.R

#Warto na początku wspomnieć jak często wykonują się dane części pliku server.R. Otóż:
###
### #To co umieścimy przed funkcja shinySerwer wykona się tylko raz (np po wrzuceniu na serwer)
### #Tutaj zatem ładujemy wszystkie biblioteki i duże zbiory danych, które oczyszczamy
###
### shinyServer(function(input,output){
### #Środek funkcji shinyServer() wykona się za każdym razem, gdy przybędzie nowy użytkownik
### #na komputerze nie zrobi nam to różnicy (wykonanie jednokrotne)
### #na serwerze - to w tym miejscu zbieramy np. dane o użytkowniku
### 
###   output$wykres <- renderPlot({
###      #Środek funkcji render_() wykona się za każdym razem, gdy zmieni się
###      #którykolwiek z argumentów input zawartych w tej funkcji
###      # tutaj uruchomienie wywołają input$dziedzna lub input$wybor
###      #daltego umieszczamy tu jak najmniej czasochłonnych obliczeń!
###
###     x <- seq(input$dziedzina[1], input$dziedzina[2], by=0.01)
###     
###     if(input$wybor==1){
###       y <- sin(x)
###     } else {
###       y <- cos(x)
###     }
###     
###     plot(x, y, type="l")
###     
###   })
### })

#Jak zwykle jednak istnieją sposoby, aby tym wykonywaniem sterować. Na początek 
#uruchom tą aplikację i spróbuj coś wpisać w tytule wykresu - obserwuj jak to się
#zmienia...
#I jak? Okazuje się, że zanim jeszcze skończysz wpisywać pełen tytuł funkcja 
#już zaczyna go przetwarzać i częściowo wypisuje go nad wykresem.
#Tutaj to jeszcze mały problem. Wyobraź sobie, gdyby np. do kontrolki z tekstem
#wpisywać np. markę samochodu, której wyszukujemy w kilku gigabajtowej bazie danych
#Chciałbyś by po wpisaniu każdej literki funkcja zaczynała przeszukiwać bazę od nowa?
#No chybaże ktoś ma dużo czasu...
#Jak temu zapobiec? Wiemy, że funkcja renderPlot() uruchomi się za każdym razem,
#gdy zmienimy input$tytul. Otóż da się to wyłączyć funkcją isolate(). Odkoduj
#linijkę w ui.R oraz te poniżej i uruchom aplikację jeszcze raz.


shinyServer(function(input,output){
  output$wykres <- renderPlot({
    x <- seq(input$dziedzina[1], input$dziedzina[2], by=0.01)
    
    if(input$wybor==1){
      y <- sin(x)
    } else {
      y <- cos(x)
    }
    
    #isolate(
    plot(x, y, type="l", main=input$tytul)
    #)
    #input$przycisk
    
  })
})

#Funkcja isolate() mówi do render - weź nie reaguj na zmianę tego co mam w środku,
#więc render jest niewrażliwe na zmianę input$tytul wykonuje się jednak gdy zmienimy
#input$wybor, input$dziedzina, lub wciśniemy przycisk