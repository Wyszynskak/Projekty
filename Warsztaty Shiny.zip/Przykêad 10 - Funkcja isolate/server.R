shinyServer(function(input,output){
  output$wykres <- renderPlot({
    x <- seq(input$dziedzina[1], input$dziedzina[2], by=0.01)
    
    if(input$wybor==1){
      y <- sin(x)
    } else {
      y <- cos(x)
    }
    
    plot(x, y, type="l", main=input$tytul)
    
  })
})
