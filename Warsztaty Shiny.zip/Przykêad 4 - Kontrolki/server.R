sciezka <- "D:/Projekty/wybory"

shinyServer(function(input,output){
  output$tekstKandydaci <- renderText({
    input$czas
    text <- readLines(paste0(sciezka, "slownik_fb_kandydaci.txt"))
    text <- paste('"', text, '"', sep="")
    text <- paste(text, seq_along(text), sep="=", collapse=", ")
    text <- paste0('list(', text, ')')
    return(text)
  })
  
  output$wykres1 <- renderPlot({
    input$czas
      x <- seq(-pi,pi,by=0.05)
      y <- sin(x)
      return(plot(x, y, type="l"))
    })
})
