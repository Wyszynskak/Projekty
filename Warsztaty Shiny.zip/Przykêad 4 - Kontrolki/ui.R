shinyUI(fluidPage(
  titlePanel("Podstawowe kontrolki"),
  
#   KONTROLKI
#   actionButton("action", label="Wciśnij mnie")
#   checkboxInput("checkbox", label="Pokaż wykres", value=TRUE )
#   checkboxGroupInput("checkGroup", label="Ulubione kolory:", 
#                      choices=list("Czerwony"=1, "Zielony"=2, "Niebieski"=3),
#                      selected=1)
#   dateInput("data", label=h3("Data"), value="2015-05-24")
#   dateRangeInput("dates", label=h3("Zakres dat", style="color:green"))
#   fileInput("file", label=h3("Wybierz plik"))
#   helpText("Notatka")
#   numericInput("numery", label=h3("Podaj liczbę"), value=1)
#   radioButtons("radio", label=h3("Płeć"), choices=list("K"=1, "M"=2), selected=1)
#   selectInput("select", label=h3("Kraj pochodzenia"), choices=list("Polska"=1,
#                                                                    "Chiny"=2, "USA"=3), selected=1)
#   textInput("text", label=h3("Tekst"), value="Imie...")
#   sliderInput("sliderJednostronny", label=h3("Suwak"), min=0, max=50, value=25)
#   sliderInput("sliderDwustronny", label=h3("Suwak 2"), min=0, max=50, value=c(25,30))

  fluidRow(

    column(3,
      h3("Przyciski"),
      actionButton("action", label = "Akcja"),
      br(),
      br(),
      submitButton("Potwierdzenie")),

    column(3,
      h3("Pojedynczy checkbox "),
      checkboxInput("checkbox", label = "Pokaż legendę", value = TRUE)),

    column(3,
      checkboxGroupInput("checkGroup",
        label = h3("Grupa checkboxów"),
        choices = list("Opcja 1" = 1,
           "Opcja 2" = 2, "Opcja 3" = 3),
        selected = 1)),

    column(3,
      dateInput("date",
        label = h3("Podaj datę"),
        value = "2015-05-24"))
  ),

  fluidRow(

    column(3,
      dateRangeInput("dates", label = h3("Zakres dat"))),

    column(3,
      fileInput("file", label = h3("Wybierz plik"))),

    column(3,
      h3("Help"),
      helpText("Notatka: helpText jest jedynym `nieinteraktywnym` widgetem")),

    column(3,
      numericInput("num",
        label = h3("Wprowadź liczbę"),
        value = 1))
  ),

  fluidRow(

    column(3,
      radioButtons("radio", label = h3("Radio buttons - wybór jeden z wielu"),
        choices = list("Tylko opcja 1" = 1, "Tylko opcja 2" = 2,
                       "Tylko opcja 3" = 3),selected = 1)),

    column(3,
      selectInput("select", label = h3("Rozwijany wybór"),
        choices = list("Opcja 1" = 1, "Opcja 2" = 2,
                       "Opcja 3" = 3), selected = 1)),

    column(3,
      sliderInput("slider1", label = h3("Suwaki"),
        min = 0, max = 100, value = 50),
      sliderInput("slider2", "",
        min = 0, max = 100, value = c(25, 75))
      ),

    column(3,
      textInput("text", label = h3("Wpisz dowolny tekst"),
        value = "Wpisz...")),
    
    column(3,
      tabsetPanel(
        tabPanel("Kobiety",
                  sliderInput("wiek", label=h3("Na ile lat się czujesz?"), min=15,
                              max=100, value=c(18,25))
        ),
        tabPanel("Mezczyzni",
                  numericInput("lata", label=h3("Ile masz lat?"), value=18)
        ),
        id="Zakladki", selected="Kobiety"
      )
    )
  )

))
