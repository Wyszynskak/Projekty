shinyUI(fluidPage(
  titlePanel("STAR WARS"),
  sidebarLayout(
    sidebarPanel(
      p("During the battle, rebel spies managed
         to steal secret plans to the Empire's
         ultimate weapon, the",strong( "DEATH STAR"),", an
         armored space station with enough power to destroy",
         em(" an entire planet."))),
    
    mainPanel(
      h6("EPISODE VI",align="center"),
      h6(code("A NEW HOPE"),align="center"),
      h5("It is a period of civil war.",align="center"),
      h4("Rebel spaceships, striking",align="center",style="color:green"),
      h3("from a hidden base, have won",align="center"),
      h2("their first victory against the",align="center"),
      h1("evil",a("Galactic Empire.",href="http://pl.wikipedia.org/wiki/Gwiezdne_wojny")),
      br(),br(),

      #Obrazek
      img(src="st.jpg")
    )
  )
))
