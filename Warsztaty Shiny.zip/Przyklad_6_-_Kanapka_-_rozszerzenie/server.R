#Najpierw przeczytaj plik ui.R

shinyServer(function(input,output){
  
    output$odpowiedz <- renderText({
      #Dzięki zmianom wprowadzonym w ui.R możemy pozbyć się instrukcji warunkowych
      #i napisać po prostu

      paste("Ok. Zrobie Ci kanapke ", input$wybor) 
      
    })
})

#Trzeba jednak uważać. Przekazujemy tu argument, który zawiera polskie znaki. 
#To zadziała na naszym komputerze, jednak podczas wrzucania na serwer możemy mieć problem 
#z kodowaniem.