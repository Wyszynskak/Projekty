#Poprzedni program możemy poprawić. 


shinyUI(fluidPage(
  titlePanel("Sandwicher"),
 sidebarLayout(
   sidebarPanel(
     
     #Tworząc listę wyborów w kontrolce tak jak poprzednio:
     #     selectInput("wybor", label="", choices= list("z serem"=1, "z szynką"=2),
     #                  selected=1)
     #użytkownikowi pokazujemy opcję "z serem", natomiast my dostajemy wartość 1.
     #Można to poprawić robiąc tak:
     
     h1("Jaką chcesz kanapkę?"),
     selectInput("wybor", label="", choices= list("z serem"="z serem",
                                                  "z szynką"="z szynką"),
                 selected=1)
     
     #Wybór zostanie przekazany do pliku server.R w zmiennej 'wybor' i tym razem
     #będzie to już tekst "z serem" lub "z szynką". 
     #przejdź teraz do pliku server.R
     ),
   mainPanel(    
     textOutput("odpowiedz")
  )
 )
))
