#Skoro już umiemy stworzyć jakieś kontrolki to przydałby się wreszcie przejść do
#sytuacji, gdy zmiana kontrolki zmienia coś w naszym programie. Zaraz stworzymy 
#swoją pierwszą interkację.
#


shinyUI(fluidPage(
  titlePanel("Sandwicher"),
 sidebarLayout(
   sidebarPanel(
     
     #W pliku ui.R tworzymy kontrolkę, która pozwoli użytkownikowi na wybór
     #'nakrycia' kanapki
     
     h1("Jaką chcesz kanapkę?"),
     selectInput("wybor", label="", choices= list("z serem"=1, "z szynką"=2),
                 selected=1)
     #Wybór zostanie przekazany do pliku server.R w zmiennej 'wybor' 
     
     ),
   mainPanel(
     #W pliku ui.R musimy też określić co chcemy dostać spowrotem od server.R
     #czyli tak jakby tutaj od razu określamy jaki typ obiektu otrzymamy i jak 
     #on będzie się nazywał. Tutatj zdecydujemy się na kawałek tekstu, który będzie
     #odpowiedzią.
     
     textOutput("odpowiedz")
     
     #Umieszczamy go tam gdzie chcemy żeby się pojawił. Możemy określić sporo typów
     #wyjściowych - podam je w kolejnym przykładzie
     #Przejdź teraz do pliku server.R
  )
 )
))
