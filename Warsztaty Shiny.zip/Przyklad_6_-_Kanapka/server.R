#Najpierw przeczytaj plik ui.R

#W pliku server.R będziemy pisać znajomy nam kod Rowy. Dzięki temu możemy dowolnie 
#modyfikować obiektu wyjściowe (zadane w pliku ui funkcjami Output).
#Zacznijmy od prostego tekstu.


shinyServer(function(input,output){
    #Wszystkie obiekty typu output znajdują się na liście output i odwołujemy 
    #się do niech poprzez zadane w pliku ui.R nazwy. (tam użyliśmy funkcji 
    # textOutput("odpowiedz")). Każdej funkcji typu _Output odpowiada funkcja
    #typu render_ tutaj użyjemy renderText.
  
    output$odpowiedz <- renderText({
      #Tekst, który zwrócimy chcemy uzależnić od tego co dostaniemy z 
      #kontrolki o nazwie 'wybor'. Wszystkie wartości poznanych dotąd kontrolek 
      #są na liście input i tak będziemy się do nich odwolywać
      
      if(input$wybor==1) tekst <- "z serem."
      if(input$wybor==2) tekst <- "z szynką."
      
      #Zwracany obiekt dla zestawu funkcji textOutput() i renderText() musi być typu character
      paste("Ok. Zrobie Ci kanapke ", tekst) 
    })
})
