#Warto by uatrakcyjnić naszą kostkę. W tym celu w folderze 'www' umieściłam zdjecia
#sześciu cyfr. Zamiast wypisywać cyfrę na ekranie zastąpimy ją ładnym obrazkiem/

shinyUI(fluidPage(
  titlePanel("Sześcienna kostka"),
  
 sidebarLayout(
   sidebarPanel(
     actionButton("przycisk", label=h3("Rzuć kostką"))
   ),
   
   mainPanel(
     #Jedyne co tu zmieniamy to typ wyjściowego argumentu
     imageOutput("liczba")
   )
 )
))
