#Najpierw przeczytaj plik ui.R

#Okazuje się, że tutaj zmiany nie są takie proste. Funkcja renderImage() ma 
#kilka ciekawych własności...


shinyServer(function(input,output){
  
  output$liczba <- renderImage({  
      #Żeby funkcja zareagowała na naciśnięcie przycisku musimy tu go wywołać
      input$przycisk 
      
      #Losujemy numer
      k <- sample(1:6,1)
      
      #samo zdjęcie musimy zwrócić w postaci list z argumentem nazwanym src
      list(src=paste("www/", k, ".jpg", sep=""))
      
      #Widzimy, że tym razem pomimo, że zdjęcia są umieszczone w katalogu 'www' 
      #funkcja nie zczyta ich automatycznie po samej nazwie
      #Na szczęście podczas działania palikacji katalogiem domyślnym staje się 
      #katalog z aplikacją. Oznacza to, że wystarczy sie odwołać tylko do katalogu 'www'
      
      #Co więcej funkcja ta ma brzydki zwyczaj... Usuwania pliku z dysku po jego wyświetleniu
      #Dziwna własność. Jeśli chcemy ją przed tym powstrzymać wystarczy dodać tak jak poniżej argument
      #deleteFile=FALSE
    }, deleteFile = FALSE)

})


#Przydatne gdy zgubi się kostka do gry ;)
