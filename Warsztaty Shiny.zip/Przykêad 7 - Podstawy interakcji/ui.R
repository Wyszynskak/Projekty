shinyUI(fluidPage(
  #htmlOutput - czysty HTML
  #imageOutput - obrazki
  #plotOutput - wykresy
  #tableOutput - tabele/ramki danych
  #textOutput - tekst
  #uiOutput - czysty HTML (używane np. w interaktywnym menu)
  #verbatimTextOutput - tekst 
   ))
