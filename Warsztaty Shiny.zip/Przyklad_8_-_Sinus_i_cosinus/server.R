

shinyServer(function(input,output){
  #Konstruujemy wykres, który ma się wyświetlić na ekranie
  output$wykres <- renderPlot({
    #Zadajemy dziedzinę funkcji
    x <- seq(input$dziedzina[1], input$dziedzina[2], by=0.01)
    
    #Jeśli użytkownik wybrał sinusa to zwracamy mu funkcję sinus
    if(input$funkcja=="sin"){
      return(plot(x, sin(x), type="l"))
      
    } else{
      #W przeciwnym przypadku funkcję cosinus
      return(plot(x, cos(x), type="l"))
    }
    
    })
})

#Jako zadanie spróbuj dodać do aplikacji możliwość wyboru koloru funkcji między
#czarnym, czerwonym i zielonym
#



