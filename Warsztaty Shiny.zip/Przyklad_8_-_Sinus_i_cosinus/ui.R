#Zróbmy teraz przykład z wykresem funkcji sinus i cosinus 
#Zakładamy, że użytkownik będzie mógł przełączać się między tymi dwoma funkcjami
#oraz, że będzie mógł zmieniać dziedzinę tej funkcji.
#


shinyUI(fluidPage(
  titlePanel("Trygonometria"),
  
  sidebarLayout(
    sidebarPanel(
      #Tutaj wstawimy kontrolki
      #Jedną do zmiany funkcji
      radioButtons("funkcja", label=h3("Funkcja:"), 
                   choices=list("Sinus"="sin", "Cosinus"="cos"), selected="sin"),
      #i drugą do zakresu dziedziny
      sliderInput("dziedzina", label=h3("Dziedzina funkcji:"), min=-2*pi,
                  max=2*pi, value=c(-pi,pi))
    ),
    
    mainPanel(
      h2("Wykres funkcji"),
      #Tutaj chcielibyśmy otrzymać wykres
      plotOutput("wykres")
    ) 
  )
))
