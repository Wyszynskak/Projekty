shinyUI(fluidPage(
   titlePanel("Bobry"),
   
   sidebarLayout(
      sidebarPanel(
         radioButtons("typ", label=h3("Typ wykresu"),
                      choices=list("Liniowy"=1, "Punktowy"=2), selected=2),
         sliderInput("df", label=h3("Ktore dane?"), min=0, max=91, value=c(10, 70))
      ),

      mainPanel(
         plotOutput("wykres")
      )
  )
))
