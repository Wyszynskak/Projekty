library("datasets")
dane<-beaver1[1:91,]

shinyServer(function(input, output) {
  output$wykres <- renderPlot({
    x <- reactive({beaver1$time[input$df[1]:input$df[2]]})
    y <- reactive({beaver1$temp[input$df[1]:input$df[2]]})
    sr <- reactive({mean(beaver1$temp[input$df[1]:input$df[2]])})
    
    plot(y()~x(),type=(if(input$typ==1)"l" else "p"))
           abline(sr(),0)
  })
})


