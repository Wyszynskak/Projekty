shinyUI(fluidPage(
  titlePanel("Portal randkowy", windowTitle="Portal randkowy"),
  sidebarLayout(
    sidebarPanel(
       h2("Preferencje"),
       sliderInput("age",label=h4("Wiek kandydata"),
          min=16,max=100,value=c(18,45)),
       br(),
       
       sliderInput("height",label=h4("Wzrost"),
          min=120,max=280,value=c(150,190)),
       br(),
       
       radioButtons("gender",label=h4("Płeć"),
          choices=list("Kobieta"=1,"Mężczyzna"=2),selected=1),
       br(),
       
       selectInput("zodiac",label=h4("Znak zodiaku"),
          choices=list("Bliźnięta"=1,"Koziorożec"=2,"Byk"=3),selected=3),
       br(),
       
       actionButton("search",label="Szukaj")
    ),
    mainPanel( h1("Twój profil"),
       fileInput("photo",label=h4("Zdjęcie profilowe")),
       textInput("name",label=h4("Imię:"),value="Imię..."),
       textInput("surname",label=h4("Nazwisko:"),value="Nazwisko..."),
       dateInput("Date",label=h4("Data urodzenia")),
       numericInput("h",label=h4("Wzrost (cm)"),value=120)
    )
  )
))
