# By nasza aplikacja mogła być interaktywna użytkownik musi mieć w co 'kliknąć',
#dlatego teraz zajmiemy się różnego rodzajmu kontrolkami. Przedstawię tutaj te 
#najbardziej podstawowe:


shinyUI(fluidPage(
  
  ##WSZYSTKIE KONTROLKI
  #Większość kontrolek ma podobną strukturę:
  #nazwaFunkcji("nazwaKontrolkiJakoObiektuRoewgo", label="EtykietaWidocznaDlaUżytkownika", 
  #              list=listaMozliwychDoPrzyjęciaWartości, selected/value=WartośćPoczątkowa)
  #"nazwaKontrolkiJakoObiektuRoewgo" będzie nazwą obiektu, doktorego będziemy
  #się odwoływać pisząc kod Rowy(użytkownik tego nie widzi)
  #"EtykietaWidocznaDlaUżytkownika" - tekst informacyjny widoczny dla użytkownika
  #listaMozliwychDoPrzyjęciaWartości - lista nazwana. Nazwy poszczególnych pół
  #listy są widoczne jako opcje wyboru dla użytkownika, zadane wartości natomiast
  #będą przekazywane do pliku server.R z kodem Rowym
  
  
  #Zwykły przycisk - widzimy, że etykiety możemy normalnie formatować
  actionButton("przycisk", label=h3("Wciśnij mnie")),
  
  #Pojedynczy checkbox - odznaczamy lub zaznaczymy jakąś opcję
  checkboxInput("checkbox", label="Pokaż wykres", value=TRUE ),
  
  #Grupa checkboxów - możliwy wybór wieloktorny
  checkboxGroupInput("checkGroup", label="Ulubione kolory:", 
                     choices=list("Czerwony"=1, "Zielony"=2, "Niebieski"=3),
                     selected=1),
  # I tutaj przykład - jezli użytkownik zaznaczy kolor Czerwony, my do R
  #dostaniemy wartość 1, jeśli zaznaczy zielony i niebieski to dostaniemy wartość
  #c(2, 3)
  
  #Wybór jeden z wielu w postaci pól do zaznaczenia
  radioButtons("radio", label=h3("Płeć"), choices=list("Kobieta"=1, "Mężczyzna"=2),
               selected=1),
  
  #Wybór jeden z wielu w postaci rozwijanej listy
  selectInput("select", label=h3("Kraj pochodzenia"), choices=list("Polska"=1,
                                                                   "Chiny"=2, "USA"=3),
              selected=1),
  #W rozwijanej liście możemy też umożliwić wybór wielokrotny
  selectInput("select", label=h3("Kraj pochodzenia"), choices=list("Polska"=1,
                                                                   "Chiny"=2, "USA"=3),
              selected=1, multiple=TRUE),
  
  #Możliwości podania daty lub jej zakresu
  dateInput("data", label=h3("Data"), value="2015-05-24"),
  dateRangeInput("dates", label=h3("Zakres dat", style="color:green")),
  
  #Załadowanie pliku
  fileInput("file", label=h3("Wybierz plik")),
  
  #Wpisywanie liczby lub tekstu
  numericInput("numery", label=h3("Podaj liczbę"), value=1),
  textInput("text", label=h3("Tekst"), value="Imie..."),
  
  #Suwaki z zakresem wartości - przydatne np. do dziedziny funkcji
  sliderInput("sliderJednostronny", label=h3("Suwak"), min=0, max=50, value=25),
  sliderInput("sliderDwustronny", label=h3("Suwak 2"), min=0, max=50, value=c(25,30)),
  
  #Test pomocniczy. Jedyna nieinteraktywna kontrolka, która nie będzie nawet
  #potrzebować nazwy obiektu Rowego, gdyż nic nie zwraca
  helpText("Krótki tekst pomocniczy")
  
  #Kontrolki wstawiałam bez Layoutu, by nie zakłócać odbioru. Można je wstawić
  #i do panelu bocznego i na ekran wynikowy
))
