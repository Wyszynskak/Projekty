

#Test dokumentacji
?wybory_pobierz_fb_likes
?wybory_pobierz_fb_posty
?wybory_pobierz_GoogleNews
?wybory_pobierz_Interia
?wybory_pobierz_Onet
?wybory_pobierz_WP
?wybory_stworz_baze
?wybory_wsk_fb_liczba_komentarz_post
?wybory_wsk_fb_liczba_like_post
?wybory_wsk_fb_liczba_postow
?wybory_wsk_fb_liczba_udostepnienie_post
?wybory_wsk_fb_likes
?wybory_wsk_fb_wzrost_likes
?wybory_wsk_GoogleNews
?wybory_wsk_artykuly
?wybory_wsk_portale_internetowe_tytuly
?wybory_wsk_tw_analiza_Wydzwieku
?wybory_wsk_tw_liczba_wystapien
?wybory_wskazniki_do_bazy
?wybory_wstaw_do_bazy

####Testy generalne
sciezka <- "D:/TestPakietu"
#Pobieranie danych
wybory_pobierz_fb_likes(sciezka_zapis = sciezka , sciezka_dostep_api = )
wybory_pobierz_fb_posty(sciezka_zapis = sciezka , sciezka_dostep_api = )
wybory_pobierz_GoogleNews(sciezka_zapis = sciezka)
wybory_pobierz_Interia(sciezka_zapis = sciezka)
wybory_pobierz_Onet(sciezka_zapis = sciezka)
wybory_pobierz_WP(sciezka_zapis = sciezka)

##Tworzenie bazy
wybory_stworz_baze(sciezka_do_bazy = paste0(sciezka,"/wybory_baza.sql"))

##Obliczanie wskaźnikow
wybory_wsk_fb_liczba_komentarz_post(okres ="dzien", wzor = "2015-05-03", sciezka_odczyt = )
wybory_wsk_fb_liczba_komentarz_post(okres ="tydzien", wzor = "2015-18", sciezka_odczyt = )
wybory_wsk_fb_liczba_komentarz_post(okres ="miesiac", wzor = "2015-05", sciezka_odczyt = )

wybory_wsk_fb_liczba_like_post(okres ="dzien", wzor = "2015-05-03", sciezka_odczyt =)
wybory_wsk_fb_liczba_like_post(okres ="tydzien", wzor = "2015-18", sciezka_odczyt =)
wybory_wsk_fb_liczba_like_post(okres ="miesiac", wzor = "2015-05", sciezka_odczyt =)

wybory_wsk_fb_liczba_postow(okres ="dzien", wzor = "2015-05-03", sciezka_odczyt =)
wybory_wsk_fb_liczba_postow(okres ="tydzien", wzor = "2015-18", sciezka_odczyt =)
wybory_wsk_fb_liczba_postow(okres ="miesiac", wzor = "2015-05", sciezka_odczyt =)

wybory_wsk_fb_liczba_udostepnienie_post(okres ="dzien", wzor = "2015-05-03", sciezka_odczyt =)
wybory_wsk_fb_liczba_udostepnienie_post(okres ="tydzien", wzor = "2015-18", sciezka_odczyt =)
wybory_wsk_fb_liczba_udostepnienie_post(okres ="miesiac", wzor = "2015-05", sciezka_odczyt =)

wybory_wsk_fb_likes(okres ="dzien", wzor = "2015-05-03", sciezka_odczyt =)
wybory_wsk_fb_likes(okres ="tydzien", wzor = "2015-18", sciezka_odczyt =)
wybory_wsk_fb_likes(okres ="miesiac", wzor = "2015-05", sciezka_odczyt =)

wybory_wsk_fb_wzrost_likes(okres ="dzien", wzor = "2015-05-03", sciezka_odczyt =)
wybory_wsk_fb_wzrost_likes(okres ="tydzien", wzor = "2015-18", sciezka_odczyt =)
wybory_wsk_fb_wzrost_likes(okres ="miesiac", wzor = "2015-05", sciezka_odczyt =)

wybory_wsk_GoogleNews(okres ="dzien", wzor = "2015-05-03", typ = "zwykly", sciezka_do_folderu = sciezka)
wybory_wsk_GoogleNews(okres ="tydzien", wzor = "2015-18", typ = "zwykly", sciezka_do_folderu = sciezka)
wybory_wsk_GoogleNews(okres ="miesiac", wzor = "2015-05", typ = "zwykly", sciezka_do_folderu = sciezka)

wybory_wsk_GoogleNews(okres ="dzien", wzor = "2015-05-03", typ = "sredni", sciezka_do_folderu = sciezka)
wybory_wsk_GoogleNews(okres ="tydzien", wzor = "2015-18", typ = "sredni", sciezka_do_folderu = sciezka)
wybory_wsk_GoogleNews(okres ="miesiac", wzor = "2015-05", typ = "sredni", sciezka_do_folderu = sciezka)


wybory_wsk_artykuly(okres ="dzien", wzor = "2015-05-03", sciezka_odczyt =sciezka, serwis="Interia")
wybory_wsk_artykuly(okres ="tydzien", wzor = "2015-18", sciezka_odczyt =sciezka, serwis="Interia")
wybory_wsk_artykuly(okres ="miesiac", wzor = "2015-05", sciezka_odczyt =sciezka, serwis="Interia")

wybory_wsk_artykuly(okres ="dzien", wzor = "2015-05-03", sciezka_odczyt =sciezka, serwis="Onet")
wybory_wsk_artykuly(okres ="tydzien", wzor = "2015-18", sciezka_odczyt =sciezka, serwis="Onet")
wybory_wsk_artykuly(okres ="miesiac", wzor = "2015-05", sciezka_odczyt =sciezka, serwis="Onet")

wybory_wsk_artykuly(okres ="dzien", wzor = "2015-05-03", sciezka_odczyt =sciezka, serwis="WP")
wybory_wsk_artykuly(okres ="tydzien", wzor = "2015-18", sciezka_odczyt =sciezka, serwis="WP")
wybory_wsk_artykuly(okres ="miesiac", wzor = "2015-05", sciezka_odczyt =sciezka, serwis="WP")


wybory_wsk_portale_internetowe_tytuly(okres ="dzien", wzor = "2015-05-03", sciezka_odczyt =sciezka, serwis="Interia")
wybory_wsk_portale_internetowe_tytuly(okres ="tydzien", wzor = "2015-18", sciezka_odczyt =sciezka, serwis="Interia")
wybory_wsk_portale_internetowe_tytuly(okres ="miesiac", wzor = "2015-05", sciezka_odczyt =sciezka, serwis="Interia")

wybory_wsk_portale_internetowe_tytuly(okres ="dzien", wzor = "2015-05-03", sciezka_odczyt =sciezka, serwis="Onet")
wybory_wsk_portale_internetowe_tytuly(okres ="tydzien", wzor = "2015-18", sciezka_odczyt =sciezka, serwis="Onet")
wybory_wsk_portale_internetowe_tytuly(okres ="miesiac", wzor = "2015-05", sciezka_odczyt =sciezka, serwis="Onet")

wybory_wsk_portale_internetowe_tytuly(okres ="dzien", wzor = "2015-05-03", sciezka_odczyt =sciezka, serwis="WP")
wybory_wsk_portale_internetowe_tytuly(okres ="tydzien", wzor = "2015-18", sciezka_odczyt =sciezka, serwis="WP")
wybory_wsk_portale_internetowe_tytuly(okres ="miesiac", wzor = "2015-05", sciezka_odczyt =sciezka, serwis="WP")


wybory_wsk_tw_liczba_wystapien(okres ="dzien", wzor = "2015-05-03", sciezka_odczyt =)

