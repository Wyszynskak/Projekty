.onAttach <- function(libname, pkgname) {
      packageStartupMessage("\n Witamy w pakiecie Wybory autorstwa Piotra Smudy i Karoliny Wyszynskiej! \n")
}
